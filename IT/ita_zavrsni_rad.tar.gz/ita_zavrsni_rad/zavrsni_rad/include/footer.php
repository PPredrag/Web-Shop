<div id="jezik"> <!--zastavice sa jezicima-->
	<a href=""><img src="./images/flags/rs.jpg" width="30" height="30" alt="RS"></a>
	<a href=""><img src="./images/flags/uk.jpg" width="30" height="30" alt="UK"></a>
	<a href=""><img src="./images/flags/de.jpg" width="30" height="30" alt="DE"></a>
	<a href=""><img src="./images/flags/sk.jpg" width="30" height="30" alt="SK"></a>
</div> <!--kraj zastavica--> 
</div>
<div id="footer">
	<p>&#169; DOOR Link, prevodilačka agencija 2013. &#183; Tel. &#43;381(0)64.193.51.62 &#183; e-mail: <a href="mailto:ivonadimitrijevic@yahoo.com">ivonadimitrijevic&#64;yahoo.com</a></p>
</div>
</div>
</body>
</html>