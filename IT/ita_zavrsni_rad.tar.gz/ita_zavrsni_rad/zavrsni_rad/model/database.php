<?php
	
	include "./classes/connection.php";
			
	$pdo=connection::getInstance();
	
?>	