<?php

	include "./include/start.php";  

	$get_page->header();
	
	include "./include/nav_menu.php";                       
	include "./include/sidebar.php";
	
	$get_page->section();
						
	include "./include/footer.php";
	
?>